package com.example.harishram.fars;

/**
 * Created by Harish Ram on 25-04-2017.
 */

public class Advertisement {
    String netID;
    String AdvertisementID;

}
