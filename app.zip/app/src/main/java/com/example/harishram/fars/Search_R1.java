package com.example.harishram.fars;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class Search_R1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search__r1);
        Toast toast1 = Toast.makeText(getApplicationContext(),"Advertisement Reported Successfully",Toast.LENGTH_LONG);
        toast1.setDuration(Toast.LENGTH_LONG);
        toast1.show();
    }
}
