package com.example.harishram.fars;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity {

    EditText netid;
    EditText pass;
    Button enter;
    String nid,pwd,nid1,pwd1,status;
    FirebaseDatabase fbd;
    DatabaseReference dbr,dbr1;
    DataSnapshot dss;
    Student sd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        netid = (EditText) findViewById(R.id.editText);
        pass = (EditText) findViewById(R.id.editText2);
        Button new_user = (Button) findViewById(R.id.button3);
        new_user.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent i= new Intent(getApplicationContext(),Sign_up.class);
                startActivity(i);
            }
        });
        enter = (Button) findViewById(R.id.button2);
        enter.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
               nid = netid.getText().toString();
               pwd = pass.getText().toString();
               fbd = FirebaseDatabase.getInstance();
               dbr = fbd.getReference("/Users/"+nid);
               //dbr1 = fbd.getReference("/Users/"+nid+"/password");
               /*String nid = dbr.getKey();
               String pwd = dbr1.getKey();*/
               //Log.d("Tag",pwd);
               dbr.addValueEventListener(new ValueEventListener() {
                   @Override
                   public void onDataChange(DataSnapshot dataSnapshot) {
                       sd = dataSnapshot.getValue(Student.class);
                       nid1 = sd.NetID;
                       pwd1 = sd.password;
                       status = sd.status;
                       Log.d("tag1",nid1);
                       Log.d("tag2",pwd1);
                       if((nid1.equals(nid))&&(pwd1.equals(pwd))){
                           Toast toast1 = Toast.makeText(getApplicationContext(),"Login successful",Toast.LENGTH_LONG);
                           toast1.setDuration(Toast.LENGTH_LONG);
                           toast1.show();
                           Intent i= new Intent(getApplicationContext(),Options.class);
                           startActivity(i);
                       }
                       else{
                           Toast toast1 = Toast.makeText(getApplicationContext(),"Invalid NetID or password.Try again",Toast.LENGTH_LONG);
                           toast1.setDuration(Toast.LENGTH_LONG);
                           toast1.show();

                       }
                   }

                   @Override
                   public void onCancelled(DatabaseError databaseError) {

                   }
               });
            }
        });
    }
}
