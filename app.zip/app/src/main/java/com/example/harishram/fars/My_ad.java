package com.example.harishram.fars;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class My_ad extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_ad);
        Toast toast1 = Toast.makeText(getApplicationContext(),"Advertisement Reported Successfully",Toast.LENGTH_LONG);
        toast1.setDuration(Toast.LENGTH_LONG);
        toast1.show();
    }
}
