package com.example.harishram.fars;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.Toast;

public class Options2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options2);
        final Button logout = (Button) findViewById(R.id.button14);

        Toast toast1 = Toast.makeText(getApplicationContext(),"User deleted Successfully",Toast.LENGTH_LONG);
        toast1.setDuration(Toast.LENGTH_LONG);
        toast1.show();
        logout.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent i= new Intent(getApplicationContext(),Login.class);
                startActivity(i);
            }});
    }
}
