package com.example.harishram.fars;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import android.widget.Toast;

public class Options extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
        final Button logout = (Button) findViewById(R.id.button13);
        final Button pad = (Button) findViewById(R.id.button7);
        Toast toast1 = Toast.makeText(getApplicationContext(),"Advertisement deleted Successfully",Toast.LENGTH_LONG);
        toast1.setDuration(Toast.LENGTH_LONG);
        toast1.show();
        logout.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
               Intent i = new Intent(getApplicationContext(),Login.class);
               Toast toast = Toast.makeText(getApplicationContext(),"Logout Successfull",Toast.LENGTH_LONG);
               toast.setDuration(Toast.LENGTH_LONG);
               toast.show();
               startActivity(i);
            }
        });
        pad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent i=new Intent(getApplicationContext(),Post_ad.class);
               startActivity(i);
            }
        });
        
    }
}
